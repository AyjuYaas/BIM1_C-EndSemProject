#include<stdio.h>
#include<stdlib.h>
#include<time.h>
#include<string.h>
#include"designers_info.h"
#include"routine.h"

void title_screen();
void delay(float);
void dep_reg_screen();
void department_Lscreen();
void department_screen();
int routine_view();
void edit_dep_record(char u_name[]);

struct dep_details{
    char un[10];
    char pw[15];
    char dname[40];
    int dobm, dobd, doby;
    int em, ed, ey;
    char uni[40];
    char hod[20];
}dep, depch, depch1; //All these variable names can be used for above variables

int main(){

    title_screen();

    return 0;

}

void title_screen(){

    system("cls");
    int choice;
    printf ("\tWELCOME TO *** LOGIN PAGE\n\n");
    printf ("Please Choose from the following options\n\n");
    printf ("\t[1] Teacher Login\n");
    printf ("\t[2] Student Login\n");
    printf ("\t[3] Department login\n");
    printf ("\t[4] Developers Info\n");
    printf ("\t[5] Exit\n");
    printf ("\tChoose: ");
    scanf ("%d", &choice);

    switch (choice) {
        case 1:
            //teacher_screen();
            break;

        case 2:
            //student_screen();
            break;

        case 3:
            department_Lscreen();
            break;

        case 4:
            animation();
            delay(0.5);
            title_screen();
            break;

        case 5:
            exit(1);
            break;
            
        case 32715:
            dep_reg_screen();
            break;

        default:
            printf ("Invalid entry");
            delay(1);
            title_screen();
    }

}

void dep_reg_screen(){
    int i, choose;

    system("cls");
  /** LOADING SCREEN **/
    printf("Restricted Area Loading");
    for(i=0; i<7; i++){
        printf(".");
        delay(0.2);
    }
    system("cls");

  /** CHOOSING SCREEN **/
    dep_create_choose:
    printf("Welcome To Department Creation Page\n\n");
    printf("\t[1] Add a New Department\n");
    printf("\t[2] Exit to Main Screen\n\n");
    printf("Choose: ");
    scanf("%d%*c", &choose);

    if (choose == 2){
        title_screen();
    }    
    else if (choose != 1){
        printf("Wrong Entry!!!");
        delay(0.6);
        system("cls");
        goto dep_create_choose;
    }

    system("cls");

  /** Department Username Password **/
    FILE *dcheck;
    dcheck = fopen("DUP.dat", "r");
    
    user:
    printf("\tDepartment Creation!!!\n\n");
    printf("NOTE: Username Shouldn't contain any space, 5 - 10 Character\n\n");
    printf("Create a Username for Department: ");
    scanf("%s%*c", &dep.un);
    depch.un[10] = '\0';
    depch.pw[15] = '\0';

    while (fscanf(dcheck, "%s %s\n", depch.un, depch.pw) != EOF){
        if (strcmp(dep.un, depch.un) == 0){
            printf("\nUsername Already Taken!!!");
            printf("\nTry Again with Another USERNAME");
            delay(1);
            rewind(dcheck);
            goto user;
        }
    }

    pass:
    printf("\nPassword Must Be Between 5 And 15 Character");
    printf("\nCreate Password: ");
    scanf("%s%*c", dep.pw);
    if (strlen(dep.pw)<5 || strlen(dep.pw)>15){
        printf("\nPassword Requirement Not Met, Try Again!!!");
        delay(1);
        goto pass;
    }
    fclose(dcheck);
    
    FILE *dup;
    dup = fopen("DUP.dat", "a");
    fprintf(dup, "%s %s\n", dep.un, dep.pw);
    fclose(dup);

    printf("\nAccount Created!!!");
    printf("\nFill Up The Remaining Details");

  /** DEPARTMENT FURTHER DETAILS **/
    printf("\n\nEnter the Name of Department: ");
    gets(dep.dname);
    fflush(stdin);
    
    printf("Enter the Established Date (In Format mm/dd/yyyy): ");
    scanf("%d/%d/%d", &dep.em, &dep.ed, &dep.ey);
    fflush(stdin);

    printf("Enter The Affiliated University: ");
    gets(dep.uni);
    fflush(stdin);

    printf("Enter the name of HOD of the Dep: "); 
    gets(dep.hod);
    fflush(stdin);
    
    FILE *dd;
    dd = fopen("dep_details.dat", "a+");
    fprintf (dd, "%s|%s|%.2d/%.2d/%.4d|%s|%s\n", dep.un, dep.dname, dep.em, dep.ed, dep.ey, dep.uni, dep.hod);
    fclose(dd);

    printf("\nDepartment Account Created..");
    printf("\nReturning to Main Screen .");  
    for(i=0; i<5; i++){
        printf(".");
        delay(0.2);
    }
    system("cls");
    title_screen();      

}

void department_Lscreen(){

    int flag = 0, choice;
    system("cls");
    printf("\tDepartment Login!!!!");
    printf("\n\nEnter Username: ");
    scanf("%s%*c", dep.un);
    printf("Enter Password: ");
    scanf("%s%*c", dep.pw);

    FILE *deptche;
    deptche = fopen("DUP.dat", "r");
    while(fscanf(deptche, "%s %s\n", depch.un, depch.pw) != EOF){
        if(strcmp(dep.un, depch.un)==0 && strcmp(dep.pw, depch.pw)==0){
            flag = 1;
            system("cls");
            goto success;
        } 
    }
    if(flag == 0){
        printf("Username/Password Incorrect!!!\n");
        redo_dep:
        printf("[1] Try Again?\n");
        printf("[2] Main Menu\n");
        printf("[3] Exit\n");
        printf("Choose: ");
        scanf("%d", &choice);
        if(choice == 1){
            department_Lscreen();
        }
        else if(choice == 2){
            fclose(deptche);
            title_screen();
        }
        else if(choice == 3){
            fclose(deptche);
            exit(2);
        }
        else{
            printf("Wrong Entry!!");
            printf("Enter Correctly!!");
            delay(1);
            goto redo_dep;  
        }
        
    } 

    success:
    system("cls");
    FILE *dfp = fopen("dep_details.dat", "r");
    while((fscanf(dfp, "%[^|]|%[^|]|%d/%d/%d|%[^|]|%[^\n]\n", &depch1.un, &depch1.dname, &depch1.em, &depch1.ed, &depch1.ey, &depch1.uni, &depch1.hod)) != EOF){
        if(strcmp(depch1.un, depch.un) == 0){
            printf("\t\t%s Department", depch1.dname);
            fclose(deptche);
            break;
        }
    }
    fclose(dfp);
    int dep_after_L_choose;
    printf("\n[1] Make Routine");
    printf("\n[2] View Routine");
    printf("\n[3] View Details");
    printf("\n[4] Edit Details");
    printf("\n[5] Logout");
    printf("\n[6] Exit");
    printf("\nChoose: ");
    scanf("%d", &dep_after_L_choose);

    switch (dep_after_L_choose)
    {
    case 1:
        int R_Check = routine_maker();
        if (R_Check == 0){
            system("cls");
            goto success;
        }
        else{
            printf("Some Error Occured While Creating Routine: ");
            delay(1);
            system("cls");
            goto success;
        }
        break;

    case 2:
        int r_v_check = routine_view();
        goto success;
        break;

    case 3:
        printf("\nYour Details: ");
        printf("\nDepartment Name: %s", depch1.dname);
        printf("\nEstablished (mm/dd/yyyy): %.2d/%.2d/%.4d", depch1.em, depch1.ed, depch1.ey);
        printf("\nAffiliated University: %s", depch1.uni);
        printf("\nHOD: %s", depch1.hod);
        printf("\nPress Any Key to Go Back...");
        fflush(stdin);
        getchar();
        goto success;
        break;

    case 4:
        edit_dep_record(depch1.un);
        goto success;
        break;
        
    case 5:
        title_screen();
        break;
    case 6:
        exit(3);
        break;
    
    default:
        printf("Wrong Entry!! Try Again!");
        system("cls");
        goto success;
    }
    
}


int routine_view(){
    system("cls");
    FILE *fp = fopen("routine.txt", "r");
    char c;
    while ((c=fgetc(fp)) != EOF){
        putchar(c);
    }
    fclose(fp);

    printf("\nPress any Key to go back...");
    getche();
    return 0;
}

void edit_dep_record(char u_name[]){
    system("cls");
    FILE *nrf = fopen("new.dat", "w");
    FILE *prf = fopen("dep_details.dat", "r");

    if(nrf==NULL || prf == NULL){
        printf("Error Opening File");
    }
    
    while((fscanf(prf, "%[^|]|%[^|]|%d/%d/%d|%[^|]|%[^\n]\n", &depch1.un, &depch1.dname, &depch1.em, &depch1.ed, &depch1.ey, &depch1.uni, &depch1.hod)) != EOF){
        if(strcmp(depch1.un, u_name) == 0){
            printf("\t\t%s Department", depch1.dname);
            break;
        }
    }

    printf("\nYour Current Details: ");
    printf("\nDepartment Name: %s", depch1.dname);
    printf("\nEstablished (mm/dd/yyyy): %.2d/%.2d/%.4d", depch1.em, depch1.ed, depch1.ey);
    printf("\nAffiliated University: %s", depch1.uni);
    printf("\nHOD: %s", depch1.hod);
    fflush(stdin);

    printf("\n\nUpdate Fields:\n");
    printf("\nEnter New Department Name: ");
    gets(depch1.dname);
    fflush(stdin);
    printf("New Established Date (mm/dd/yyyy): ");
    scanf("%d/%d/%d", &depch1.em, &depch1.ed, &depch1.ey);
    fflush(stdin);
    printf("New Affiliated University: ");
    gets(depch1.uni);
    fflush(stdin);
    printf("New Department HOD Name: ");
    gets(depch1.hod);
    fflush(stdin);

    fprintf (nrf, "%s|%s|%.2d/%.2d/%.4d|%s|%s\n", depch1.un, depch1.dname, depch1.em, depch1.ed, depch1.ey, depch1.uni, depch1.hod);

    rewind(prf);
    while((fscanf(prf, "%[^|]|%[^|]|%d/%d/%d|%[^|]|%[^\n]\n", &depch.un, &depch.dname, &depch.em, &depch.ed, &depch.ey, &depch.uni, &depch.hod)) != EOF){
        if(strcmp(depch1.un, depch.un) == 0){
        }
        else{
            fprintf (nrf, "%s|%s|%.2d/%.2d/%.4d|%s|%s\n", depch1.un, depch1.dname, depch1.em, depch1.ed, depch1.ey, depch1.uni, depch1.hod);
        }
    }
    fclose(nrf);
    fclose(prf);

    remove("dep_details.dat");
    rename("new.dat", "dep_details.dat");
    printf("Update Successful!!");
    printf("\nPress any key to return to home screen...");
    getche();
}

void delay(float sec) 
{
    // Converting time into milli_seconds
    int milli_seconds = 1000 * sec;
  
    // Storing start time
    clock_t start_time = clock();
  
    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds)
        ;

    /* This Piece of code Was Taken from stackoverflow.com */
}