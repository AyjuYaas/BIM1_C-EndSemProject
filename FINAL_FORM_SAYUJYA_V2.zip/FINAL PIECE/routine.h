#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
#include<time.h>

void delayfr(float sec);
void trim(char * str);

char * routine_maker(){

    system("cls");
/****************** INITIALIZATION 1 ************************/
    printf(" ROUTINE MAKING PROGRAM \n\n");
    int no; 
    char days[7][3] = {"SUN", "MON", "TUE", "WED", "THU", "FRI", "SAT"};
    int period;
    int t, i=0, j, d, n, l, op, lp1;
    int per, pert, nic;

/************* DAY SELECT ******************/

    day_select:
    int ed, sd, td;
    printf("\nIf:\n\n[1] Sunday\n[2] Monday\n[3] Tuesday\n[4] Wednesday\n[5] Thursday\n[6] Friday\n[7] Saturday");
    printf ("\n\nChoose a starting day and a ending day for routine\n");
    printf("\nNOTES:\nA> Choose Start and End Day, EG: 1 & 6 For Sunday to Friday\nB> For Only 1 Day routine Enter the same number (eg 1 & 1 for Sunday)");
    printf("\nC> Descending order is not allowed: eg; 7 - 1 (i.e. Sat to Sun is prohibitted)");
    printf("\n\nChoose Start Day: ");
    scanf("%d%*c", &sd);

    if(sd<1 || sd>7){
        getchar();
        printf("\nError! Out of Range Value!");
        delayfr(1);
        system("cls");
        goto day_select;
    }

    re:
    printf("\nChoose End Day: ");
    scanf("%d%*c", &ed);

    if(ed<1 || ed>7){
        getchar();
        printf("\nError! Out of Range Value!");
        delayfr(0.6);
        goto re;
    }

    td = (ed - sd);

    if(td<0){
        printf("Error! Wrong Format\n");
        delayfr(1);
        system("cls");
        goto day_select;
    }
    td = (ed-sd)+1;

/********** INITIALIZATION 2 ***************/

    printf("\nEnter the Total Number of Periods You Want(In a Day): ");
    scanf("%d%*c", &period);

    printf("\nEnter the Number of Routines You Want to Make: ");
    scanf("%d%*c", &no);

    char fac[no][15];

    char ch1[11] = ">>>       ";

    int tp = (td*period);
    
    char sub[no][tp][14];
    char error_sub[no][tp][15];

    system("cls");

/********** ROUTINE MAKING ************/
    for(t=0; t<no; t++){
 
        printf("\nRoutine no. %d\nGrade/Faculty for this Routine: ", (t+1));
        scanf("%[^\n]%*c", fac[t]);
        strupr(fac[t]);

        for(i=0; i<tp; i++){
            sub[t][i][14] = '\0';
        }

        system("cls");

        for(op=0; op<tp; op++){
            lp1 = (sd-1);
            printf("Routine no. %d\n", (t+1));
            printf("Grade/Faculty = %s\n", fac[t]);
            strcpy(sub[t][op], ch1);

            for(i=0; i<td; i++){
                n = i;

                if (i==0){
                    printf("----------");
                    for(l=1; l<=(period); l++){
                        printf("------------------");
                    }
                    printf("\n|%5.3s\t", "D/P");
                    for(l=0; l<period; l++){
                        printf("|      %-10d ", l+1);
                    }
                    printf("|\n");
                    printf("----------");
                    for(l=1; l<=(period); l++){
                        printf("------------------");
                    }
                }

                printf("\n|%5.3s\t", days[lp1]);
                lp1 += 1;

                per = (n*period);
                pert = ((n+1)*period);
                d = 0;
                
                for (j=per; j<pert; j++){
                    printf ("| %-15.14s ", sub[t][j]);
                }

                printf ("|\n");

                printf("----------");
                for(l=1; l<=(period); l++){
                    printf("------------------");
                }

            }

            printf("\nEnter the Subject Down Below to Replace the Pointer '>>>' [Max 14 letters (including space)]:\n");
            printf("Enter Here: ");
            fgets(sub[t][op], 14, stdin);
            fflush(stdin);
            
            trim(sub[t][op]);
            strupr(sub[t][op]);
            system("cls");
        }

        if(op == (tp-1)){
            delayfr(1);
            system("cls");
        }
    }
    
/******** Collison Detactor *******/

    for(t=0; t<no; t++){
        for(i=0; i<tp; i++){
            strcpy(error_sub[t][i], sub[t][i]);
        }
    }

    int flag = 0;
    int k, w;
    int res;

    for (t=0; t<(no-1); t++){
        for(i=0; i<td; i++){
            n = i;
            per = (n*period);
            pert = ((n+1)*period);
            d = 0;

            for (j=per; j<pert; j++){
                d += 1;
                w = (t+1);
                for (k=w; k<no; k++){
                    if (strcmp(error_sub[t][j], error_sub[k][j]) == 0){
                        strcat (error_sub[t][j], " <");
                        strcat (error_sub[k][j], " <");
                        flag++;
                    }
                }
            }
        }
    }

/****** Showing Errors ******/
    if(flag != 0){

        for(t=0; t<no; t++){
            printf("\n\n");

            lp1 = (sd-1);
            printf("Routine no. %d\n", (t+1));
            printf("Faculty = %s\n", fac[t]);

            for(i=0; i<td; i++){
                n = i;

                if (i==0){
                    printf("----------");
                    for(l=1; l<=(period); l++){
                        printf("------------------");
                    }
                    printf("\n|%5.3s\t", "D/P");
                    for(l=0; l<period; l++){
                        printf("|      %-10d ", l+1);
                    }
                    printf("|\n");
                    printf("----------");
                    for(l=1; l<=(period); l++){
                        printf("------------------");
                    }
                }
                
                printf("\n|%5.3s\t", days[lp1]);
                lp1 += 1;

                per = (n*period);
                pert = ((n+1)*period);
                d = 0;
                
                for (j=per; j<pert; j++){
                    printf ("| %-16.15s", error_sub[t][j]);
                }

                printf ("|\n");

                printf("----------");
                for(l=1; l<=(period); l++){
                    printf("------------------");
                }

            }

        }

        solve_q:
        printf ("\n%d collisions Detected In Subjects Marked '<'\nWant to Solve?\n[1] Yes\n[2] No\nChoose: ", flag);
        scanf("%d", &res);
        fflush(stdin);
        if(res == 1)
            goto solve;
        
        else if (res == 2)
            goto final_print;

        else{
            printf("\nError, Wrong Response: ");
            delayfr(1);
            goto solve_q;
        }

    }

/***** Collison Solver *****/
    solve:
    int error;
    int solve, soln;
    char noo = 1;
    char ch = ' ';
    do{ 
        error = 0;
        for (t=0; t<(no-1); t++){
            for(i=0; i<td; i++){
                n = i;
                per = (n*period);
                pert = ((n+1)*period);
                d = 0;
                lp1 = (sd-1);

                for (j=per; j<pert; j++){
                    d += 1;
                    w = (t+1);
                    for (k=w; k<no; k++){
                        if (strcmp(sub[t][j], sub[k][j]) == 0){
                            printf("\nCollision No. %d", noo);
                            printf ("\nCollision on %.3s period %d on %s & %s ", days[lp1], d, fac[t], fac[k]);
                            printf ("(%s = %s)", sub[t][j], sub[k][j]);

                            error = 1;
                            flag = 1;
                            noo++;
                            solve_part:
                            solve = '\0';
                            printf ("\nSolve it?\n[1] YES\n[2] NO\nChoose: ");
                            scanf("%d", &solve);
                            fflush(stdin);

                            if (solve == 1){
                                soln_part:
                                printf ("\nMake changes to:\n[1] Make Changes to %s\n[2] to Make Changes to %s\nChoose: ", fac[t], fac[k]);
                                scanf("%d", &soln);
                                fflush(stdin);

                                if(soln == 1){
                                    printf ("%s Faculty %.3s period %d: ", fac[t], days[lp1], d);
                                    scanf("%s", sub[t][j]);
                                    strupr(sub[t][j]);
                                }

                                else if (soln == 2){
                                    printf ("%s Faculty %.3s period %d: ", fac[k], days[lp1], d);
                                    scanf("%s", sub[k][j]);
                                    strupr(sub[k][j]);
                                }

                                else{
                                    printf ("\nInvalid Entry!!");
                                    delayfr(1);
                                    goto soln_part;
                                }
                            }

                            else if (solve == 2){
                                strcat(sub[k][j], " ");
                                lp1 += 1;
                                continue;
                            }

                            else{
                                printf ("Invalid Entry!!");
                                delayfr(1);
                                goto solve_part;
                            }
                        }
                    }
                }

                lp1 += 1;
            }
        }
    }while (error == 1);

/****** THE FINAL OUTPUT ******/
    final_print:
    printf("\nThe Final Routine/s: ");
    for(t=0; t<no; t++){
        printf("\n\n");

        lp1 = (sd-1);
        printf("Routine no. %d\n", (t+1));
        printf("Faculty = %s\n", fac[t]);

        for(i=0; i<td; i++){
            n = i;

            if (i==0){
                printf("----------");
                for(l=1; l<=(period); l++){
                    printf("------------------");
                }
                printf("\n|%5.3s\t", "D/P");
                for(l=0; l<period; l++){
                    printf("|      %-10d ", l+1);
                }
                printf("|\n");
                printf("----------");
                for(l=1; l<=(period); l++){
                    printf("------------------");
                }
            }

            printf("\n|%5.3s\t", days[lp1]);
            lp1 += 1;

            per = (n*period);
            pert = ((n+1)*period);
            d = 0;
            
            for (j=per; j<pert; j++){
                printf ("| %-16.15s", sub[t][j]);
            }

            printf ("|\n");

            printf("----------");
            for(l=1; l<=(period); l++){
                printf("------------------");
            }

        }

    }
    
/**** FIlE PRINTING ****/
    static char r_name[30], temp[30];
    int a = 0;
    printf("\n\nEnter the name of routine you want to save as(eg: ABC.txt, .txt is mandatory\n");
    gets(r_name);
    fflush(stdin);
    FILE *op12 = fopen("routinelist.txt", "a+");
    while(fscanf(op12, "%d %[^\n]\n", &a, &temp) != EOF){
    }
    rewind(op12);
    fprintf(op12, "%d %s\n", a+1, r_name);
    fclose(op12);
    FILE *rot = fopen(r_name, "w+");

    for(t=0; t<no; t++){
        if(t!=0){
            fprintf(rot, "\n\n");
        }
        
        lp1 = (sd-1);
        fprintf(rot, "%s\n", fac[t]);

        for(i=0; i<td; i++){
            n = i;

            if (i==0){
                fprintf(rot, "----------");
                for(l=1; l<=(period); l++){
                    fprintf(rot, "------------------");
                }
                fprintf(rot, "\n|%5.3s\t", "D/P");
                for(l=0; l<period; l++){
                    fprintf(rot, "|      %-10d ", l+1);
                }
                fprintf(rot, "|\n");
                fprintf(rot, "----------");
                for(l=1; l<=(period); l++){
                    fprintf(rot, "------------------");
                }
            }

            fprintf(rot, "\n|%5.3s\t", days[lp1]);
            lp1 += 1;

            per = (n*period);
            pert = ((n+1)*period);
            d = 0;
            
            for (j=per; j<pert; j++){
                fprintf (rot, "| %-16.15s", sub[t][j]);
            }

            fprintf (rot, "|\n");

            fprintf(rot, "----------");
            for(l=1; l<=(period); l++){
                fprintf(rot, "------------------");
            }

        }

    }
    fclose(rot);

    printf("\nThis Final Routine Can be Found on '%s' file on the same directory as this exe file", r_name);

    printf("\nPress Any Key To Exit: ");
    getche();

    return r_name;
}

void delayfr(float sec) 
{
    // Converting time into milli_seconds
    int milli_seconds = 1000 * sec;
  
    // Storing start time
    clock_t start_time = clock();
  
    // looping till required time is not achieved
    while (clock() < start_time + milli_seconds)
        ;

    /* This Piece of code Was Taken from stackoverflow.com */
}

void trim(char * str)
{
    int index, i;

    index = -1, i = 0;

    while(str[i] != '\0'){ //Finds the End Index of Non-White Space
    
        if(str[i] != ' ' && str[i] != '\t' && str[i] != '\n'){
            index= i;
        }

        i++;
    }

    str[index + 1] = '\0'; //Mark the 
}